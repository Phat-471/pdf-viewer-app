<?php get_header(); ?>

<main class="site-main">
	<!-- 1. HERO BANNER -->
	<section class="hero-banner">
		<div class="hero-content">
			<h1>THIẾT BỊ VỆ SINH CAO CẤP & THI CÔNG TRỌN GÓI</h1>
			<p>Giải pháp phòng tắm hoàn hảo từ thiết kế, thi công đến lắp đặt thiết bị chính hãng từ 6 thương hiệu hàng đầu.</p>
			<div class="hero-buttons">
				<?php $zalo_url = get_theme_mod( 'sanitary_zalo_url', 'https://zalo.me/0901234567' ); ?>
				<a href="<?php echo esc_url( $zalo_url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-accent">Nhận báo giá qua Zalo</a>
				<a href="#brands" class="btn btn-secondary">Xem các hãng liên kết</a>
			</div>
		</div>
	</section>

	<!-- 2. SERVICES SECTION -->
	<section class="services-section container">
		<h2 class="section-title">DỊCH VỤ CHUYÊN NGHIỆP</h2>
		<p class="section-subtitle">Quy trình trọn gói mang lại sự an tâm tuyệt đối cho khách hàng.</p>
		
		<div class="services-grid">
			<div class="service-card">
				<div class="service-icon">✏️</div>
				<h3>1. THIẾT KẾ PHÒNG TẮM</h3>
				<p>Tư vấn bố trí không gian, thiết kế bản vẽ kỹ thuật 2D/3D phù hợp với phong thủy và diện tích nhà bạn.</p>
			</div>

			<div class="service-card">
				<div class="service-icon">🏗️</div>
				<h3>2. THI CÔNG TRỌN GÓI</h3>
				<p>Thi công đường nước, chống thấm, ốp lát gạch nền tường chuẩn kỹ thuật trước khi lắp đặt thiết bị.</p>
			</div>

			<div class="service-card">
				<div class="service-icon">🔧</div>
				<h3>3. LẮP ĐẶT THIẾT BỊ</h3>
				<p>Lắp ráp bồn cầu, chậu rửa, sen vòi, bồn tắm chuyên nghiệp, đảm bảo không rò rỉ, bảo hành chính hãng.</p>
			</div>
		</div>
	</section>

	<!-- 3. BRAND LIST SECTION -->
	<section id="brands" class="brands-section">
		<div class="container">
			<h2 class="section-title">6 HÃNG THƯƠNG HIỆU ĐỒNG HÀNH</h2>
			<p class="section-subtitle">Click vào hãng để xem các dòng sản phẩm của hãng đó.</p>

			<div class="brands-grid">
				<?php
				$brands = get_terms([
					'taxonomy'   => 'product_brand',
					'hide_empty' => false,
				]);
				if ( ! is_wp_error( $brands ) && ! empty( $brands ) ) :
					foreach ( $brands as $brand ) :
						$brand_link = get_term_link( $brand );
						if ( ! is_wp_error( $brand_link ) ) :
							?>
							<a href="<?php echo esc_url( $brand_link ); ?>" class="brand-card">
								<span class="brand-name"><?php echo esc_html( $brand->name ); ?></span>
							</a>
							<?php
						endif;
					endforeach;
				else :
					?>
					<div class="brand-card"><span class="brand-name">GIFTO</span></div>
					<div class="brand-card"><span class="brand-name">GIFTO GOLD</span></div>
					<div class="brand-card"><span class="brand-name">MANDY</span></div>
					<div class="brand-card"><span class="brand-name">SDUY</span></div>
					<div class="brand-card"><span class="brand-name">TAKAMI</span></div>
					<div class="brand-card"><span class="brand-name">TQC</span></div>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- 4. PRODUCT CATALOG GRID -->
	<section class="products-section container">
		<h2 class="section-title">SẢN PHẨM MỚI CẬP NHẬT</h2>
		<p class="section-subtitle">Danh mục thiết bị vệ sinh catalogue nổi bật.</p>

		<?php
		$product_args = [
			'post_type'      => 'sanitary_product',
			'posts_per_page' => 6,
		];
		$products_query = new WP_Query( $product_args );

		if ( $products_query->have_posts() ) :
			?>
			<div class="products-grid">
				<?php while ( $products_query->have_posts() ) : $products_query->the_post(); ?>
					<div class="product-card">
						<a href="<?php the_permalink(); ?>" class="product-img-link">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'medium_large' ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/placeholder.jpg' ); ?>" alt="<?php the_title_attribute(); ?>">
							<?php endif; ?>
						</a>
						<div class="product-info">
							<span class="product-brand-tag">
								<?php
								$terms = get_the_terms( get_the_ID(), 'product_brand' );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									echo esc_html( $terms[0]->name );
								}
								?>
							</span>
							<h3 class="product-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<p class="product-excerpt"><?php echo wp_trim_words( get_the_excerpt(), 15 ); ?></p>
							<a href="<?php the_permalink(); ?>" class="view-detail-btn">Xem chi tiết</a>
						</div>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<div class="no-products">
				<p>Chưa có sản phẩm nào được cập nhật. Bạn hãy vào mục <strong>Sản phẩm -> Thêm mới</strong> trong Admin để đăng bài.</p>
			</div>
		<?php endif; ?>
	</section>
</main>

<?php get_footer(); ?>
