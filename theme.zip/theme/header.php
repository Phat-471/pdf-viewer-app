<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
	<div class="header-container">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php theme_custom_logo(); ?>
			<?php else : ?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			<?php endif; ?>
		</div>

		<nav id="site-navigation" class="main-navigation">
			<?php
			wp_nav_menu( [
				'theme_location' => 'primary-menu',
				'menu_id'        => 'primary-menu',
				'container'      => false,
				'fallback_cb'    => 'wp_page_menu',
			] );
			?>
		</nav>

		<div class="header-cta">
			<?php
			$hotline = get_theme_mod( 'sanitary_hotline', '090 123 4567' );
			$hotline_tel = get_theme_mod( 'sanitary_hotline_tel', '0901234567' );
			?>
			<a href="tel:<?php echo esc_attr( $hotline_tel ); ?>" class="cta-button">Hotline: <?php echo esc_html( $hotline ); ?></a>
		</div>
	</div>
</header>
