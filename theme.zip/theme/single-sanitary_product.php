<?php get_header(); ?>

<main class="site-main container">
	<div class="product-detail-layout">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="product-gallery">
				<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'large', [ 'class' => 'featured-product-image' ] ); ?>
				<?php else : ?>
					<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/placeholder.jpg' ); ?>" class="featured-product-image" alt="<?php the_title_attribute(); ?>">
				<?php endif; ?>
			</div>

			<div class="product-summary">
				<div class="product-meta-header">
					<span class="product-brand-label">Hãng sản xuất: </span>
					<span class="product-brand-value">
						<?php
						$terms = get_the_terms( get_the_ID(), 'product_brand' );
						if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
							$brand_links = [];
							foreach ( $terms as $term ) {
								$brand_links[] = '<a href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $term->name ) . '</a>';
							}
							echo implode( ', ', $brand_links );
						} else {
							echo 'Chưa phân loại';
						}
						?>
					</span>
				</div>

				<h1 class="product-detail-title"><?php the_title(); ?></h1>
				
				<div class="product-detail-excerpt">
					<?php the_excerpt(); ?>
				</div>

				<div class="product-cta-box">
					<h3>Nhận Báo Giá & Tư Vấn Lắp Đặt</h3>
					<p>Sản phẩm chính hãng, hỗ trợ khảo sát tại công trình và lắp đặt hoàn thiện trọn gói bởi kỹ thuật viên kinh nghiệm.</p>
					<?php
					$hotline = get_theme_mod( 'sanitary_hotline', '090 123 4567' );
					$hotline_tel = get_theme_mod( 'sanitary_hotline_tel', '0901234567' );
					$zalo_url = get_theme_mod( 'sanitary_zalo_url', 'https://zalo.me/0901234567' );
					?>
					<div class="cta-actions">
						<a href="<?php echo esc_url( $zalo_url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-zalo">Liên hệ Zalo báo giá</a>
						<a href="tel:<?php echo esc_attr( $hotline_tel ); ?>" class="btn btn-phone">Gọi ngay: <?php echo esc_html( $hotline ); ?></a>
					</div>
				</div>
			</div>

			<div class="product-description-tabs">
				<h2 class="tab-title">Thông tin chi tiết sản phẩm</h2>
				<div class="tab-content">
					<?php the_content(); ?>
				</div>
			</div>
		<?php endwhile; endif; ?>
	</div>
</main>

<?php get_footer(); ?>
