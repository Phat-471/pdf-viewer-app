<?php
/**
 * Sanitary Catalog Theme functions and definitions
 * Developed with strict compatibility for PHP 7.4 - PHP 8.3+
 *
 * @package Sanitary_Catalog_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Basic Theme Setup
 */
function sanitary_theme_setup() {
	// Support dynamic title tags
	add_theme_support( 'title-tag' );

	// Enable featured images (thumbnails)
	add_theme_support( 'post-thumbnails' );

	// Add block editor alignment support
	add_theme_support( 'align-wide' );

	// Editor styles support
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );

	// Support responsive embeds
	add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'sanitary_theme_setup' );

/**
 * Register Custom Post Type: Product (Sản phẩm)
 */
function sanitary_register_product_cpt() {
	$labels = [
		'name'               => _x( 'Sản phẩm', 'post type general name', 'sanitary-catalog-theme' ),
		'singular_name'      => _x( 'Sản phẩm', 'post type singular name', 'sanitary-catalog-theme' ),
		'menu_name'          => _x( 'Sản phẩm', 'admin menu', 'sanitary-catalog-theme' ),
		'name_admin_bar'     => _x( 'Sản phẩm', 'add new on admin bar', 'sanitary-catalog-theme' ),
		'add_new'            => _x( 'Thêm sản phẩm mới', 'product', 'sanitary-catalog-theme' ),
		'add_new_item'       => __( 'Thêm sản phẩm mới', 'sanitary-catalog-theme' ),
		'new_item'           => __( 'Sản phẩm mới', 'sanitary-catalog-theme' ),
		'edit_item'          => __( 'Chỉnh sửa sản phẩm', 'sanitary-catalog-theme' ),
		'view_item'          => __( 'Xem sản phẩm', 'sanitary-catalog-theme' ),
		'all_items'          => __( 'Tất cả sản phẩm', 'sanitary-catalog-theme' ),
		'search_items'       => __( 'Tìm kiếm sản phẩm', 'sanitary-catalog-theme' ),
		'parent_item_colon'  => __( 'Sản phẩm cha:', 'sanitary-catalog-theme' ),
		'not_found'          => __( 'Không tìm thấy sản phẩm nào.', 'sanitary-catalog-theme' ),
		'not_found_in_trash' => __( 'Không tìm thấy sản phẩm nào trong thùng rác.', 'sanitary-catalog-theme' ),
	];

	$args = [
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => [ 'slug' => 'san-pham', 'with_front' => false ],
		'capability_type'    => 'post',
		'has_archive'        => 'danh-sach-san-pham',
		'hierarchical'        => false,
		'menu_position'      => 5,
		'menu_icon'          => 'dashicons-cart', // Cart icon fits catalog well
		'show_in_rest'       => true, // Required for Gutenberg / Block Editor
		'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
	];

	register_post_type( 'sanitary_product', $args );
}
add_action( 'init', 'sanitary_register_product_cpt' );

/**
 * Register Custom Taxonomies: Brand (Thương hiệu) & Catalog Category (Danh mục sản phẩm)
 */
function sanitary_register_taxonomies() {
	// 1. Taxonomy: Thương hiệu (product_brand)
	$brand_labels = [
		'name'              => _x( 'Thương hiệu / Hãng', 'taxonomy general name', 'sanitary-catalog-theme' ),
		'singular_name'     => _x( 'Thương hiệu', 'taxonomy singular name', 'sanitary-catalog-theme' ),
		'search_items'      => __( 'Tìm thương hiệu', 'sanitary-catalog-theme' ),
		'all_items'         => __( 'Tất cả thương hiệu', 'sanitary-catalog-theme' ),
		'parent_item'       => __( 'Thương hiệu cha', 'sanitary-catalog-theme' ),
		'parent_item_colon' => __( 'Thương hiệu cha:', 'sanitary-catalog-theme' ),
		'edit_item'         => __( 'Chỉnh sửa thương hiệu', 'sanitary-catalog-theme' ),
		'update_item'       => __( 'Cập nhật thương hiệu', 'sanitary-catalog-theme' ),
		'add_new_item'      => __( 'Thêm thương hiệu mới', 'sanitary-catalog-theme' ),
		'new_item_name'     => __( 'Tên thương hiệu mới', 'sanitary-catalog-theme' ),
		'menu_name'         => __( 'Thương hiệu / Hãng', 'sanitary-catalog-theme' ),
	];

	$brand_args = [
		'hierarchical'      => true,
		'labels'            => $brand_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => [ 'slug' => 'thuong-hieu' ],
		'show_in_rest'      => true,
	];

	register_taxonomy( 'product_brand', [ 'sanitary_product' ], $brand_args );

	// 2. Taxonomy: Danh mục sản phẩm (product_cat)
	$cat_labels = [
		'name'              => _x( 'Danh mục sản phẩm', 'taxonomy general name', 'sanitary-catalog-theme' ),
		'singular_name'     => _x( 'Danh mục', 'taxonomy singular name', 'sanitary-catalog-theme' ),
		'search_items'      => __( 'Tìm danh mục', 'sanitary-catalog-theme' ),
		'all_items'         => __( 'Tất cả danh mục', 'sanitary-catalog-theme' ),
		'parent_item'       => __( 'Danh mục cha', 'sanitary-catalog-theme' ),
		'parent_item_colon' => __( 'Danh mục cha:', 'sanitary-catalog-theme' ),
		'edit_item'         => __( 'Chỉnh sửa danh mục', 'sanitary-catalog-theme' ),
		'update_item'       => __( 'Cập nhật danh mục', 'sanitary-catalog-theme' ),
		'add_new_item'      => __( 'Thêm danh mục mới', 'sanitary-catalog-theme' ),
		'new_item_name'     => __( 'Tên danh mục mới', 'sanitary-catalog-theme' ),
		'menu_name'         => __( 'Danh mục sản phẩm', 'sanitary-catalog-theme' ),
	];

	$cat_args = [
		'hierarchical'      => true,
		'labels'            => $cat_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => [ 'slug' => 'danh-muc-san-pham' ],
		'show_in_rest'      => true,
	];

	register_taxonomy( 'product_cat', [ 'sanitary_product' ], $cat_args );
}
add_action( 'init', 'sanitary_register_taxonomies' );

/**
 * Auto-populate the 6 default brands on theme activation
 */
function sanitary_populate_default_brands() {
	$brands = [
		'GIFTO',
		'GIFTO GOLD',
		'MANDY',
		'SDUY',
		'TAKAMI',
		'TQC'
	];

	foreach ( $brands as $brand_name ) {
		// Typecast brand name safely to string for PHP compatibility
		$name = (string) $brand_name;
		if ( ! term_exists( $name, 'product_brand' ) ) {
			wp_insert_term( $name, 'product_brand' );
		}
	}
}
add_action( 'after_switch_theme', 'sanitary_populate_default_brands' );
// Also run on init to ensure terms exist even if switch_theme didn't fire properly on local env
add_action( 'init', 'sanitary_populate_default_brands', 20 );

/**
 * Enqueue Styles and Scripts
 */
function sanitary_theme_assets() {
	// Main theme stylesheet
	wp_enqueue_style( 'sanitary-main-style', get_stylesheet_uri(), [], '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'sanitary_theme_assets' );

/**
 * Add Theme Customizer options for phone numbers, address, and Zalo link
 */
function sanitary_customize_register( $wp_customize ) {
	// Section: Contact Settings
	$wp_customize->add_section( 'sanitary_contact_section', [
		'title'    => __( 'Thông tin liên hệ & Mạng xã hội', 'sanitary-catalog-theme' ),
		'priority' => 30,
	] );

	// Setting: Hotline / Số điện thoại hiển thị
	$wp_customize->add_setting( 'sanitary_hotline', [
		'default'           => '090 123 4567',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'sanitary_hotline', [
		'label'    => __( 'Số Hotline', 'sanitary-catalog-theme' ),
		'section'  => 'sanitary_contact_section',
		'type'     => 'text',
	] );

	// Setting: Số điện thoại gọi điện (dùng cho link tel:)
	$wp_customize->add_setting( 'sanitary_hotline_tel', [
		'default'           => '0901234567',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'sanitary_hotline_tel', [
		'label'    => __( 'Số Điện Thoại Gọi Đi (Không khoảng trắng)', 'sanitary-catalog-theme' ),
		'section'  => 'sanitary_contact_section',
		'type'     => 'text',
	] );

	// Setting: Zalo Link
	$wp_customize->add_setting( 'sanitary_zalo_url', [
		'default'           => 'https://zalo.me/0901234567',
		'sanitize_callback' => 'esc_url_raw',
	] );
	$wp_customize->add_control( 'sanitary_zalo_url', [
		'label'    => __( 'Đường dẫn Zalo Chat', 'sanitary-catalog-theme' ),
		'section'  => 'sanitary_contact_section',
		'type'     => 'url',
	] );

	// Setting: Địa chỉ showroom
	$wp_customize->add_setting( 'sanitary_address', [
		'default'           => 'Showroom Thiết Bị Vệ Sinh',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'sanitary_address', [
		'label'    => __( 'Địa chỉ Showroom', 'sanitary-catalog-theme' ),
		'section'  => 'sanitary_contact_section',
		'type'     => 'text',
	] );
}
add_action( 'customize_register', 'sanitary_customize_register' );
