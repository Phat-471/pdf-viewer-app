<footer class="site-footer">
	<div class="footer-container">
		<div class="footer-column branding">
			<h3 class="footer-logo"><?php bloginfo( 'name' ); ?></h3>
			<p>Chuyên cung cấp Thiết bị vệ sinh cao cấp chính hãng & Dịch vụ thiết kế, thi công, lắp đặt hoàn thiện chuyên nghiệp.</p>
		</div>

		<div class="footer-column services">
			<h4>Dịch vụ chính</h4>
			<ul>
				<li>Tư vấn & Thiết kế phòng tắm</li>
				<li>Thi công lắp đặt thiết bị</li>
				<li>Bảo hành & Bảo dưỡng định kỳ</li>
			</ul>
		</div>

		<div class="footer-column contact">
			<h4>Liên hệ tư vấn</h4>
			<?php
			$address = get_theme_mod( 'sanitary_address', 'Showroom Thiết Bị Vệ Sinh' );
			$hotline = get_theme_mod( 'sanitary_hotline', '090 123 4567' );
			$zalo_url = get_theme_mod( 'sanitary_zalo_url', 'https://zalo.me/0901234567' );
			?>
			<p><strong>Địa chỉ:</strong> <?php echo esc_html( $address ); ?></p>
			<p><strong>Điện thoại:</strong> <?php echo esc_html( $hotline ); ?></p>
			<p><strong>Zalo báo giá:</strong> <a href="<?php echo esc_url( $zalo_url ); ?>" target="_blank" rel="noopener noreferrer" style="color:#d97706; font-weight:700;">Liên hệ Zalo</a></p>
		</div>
	</div>

	<div class="footer-bottom">
		<p>&copy; <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?>. Tất cả quyền được bảo lưu.</p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
